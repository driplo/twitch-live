import React, { Component } from 'react';
import 'whatwg-fetch';

class StreamList extends Component {
  
  render() {
    if (this.props.token){
      
      const AUTH_TOKEN = this.props.token;
      
      const followedStreams = `https://api.twitch.tv/kraken/streams/followed?oauth_token=${AUTH_TOKEN}`;
      
      fetch(followedStreams)
        .then(function(response) {
          return response.json()
        }).then(function(json) {
          console.log('parsed json', json)
        }).catch(function(ex) {
          console.log('parsing failed', ex)
        });
      
      
      return(
        <div>Streamer list</div>
      )
    } else {
      return (
        <div>Log in please</div>
      )
    }
      
  }
    
}

export default StreamList;