import React, { Component } from 'react';
import logo_twitch from './logo_twitch.svg';
import './App.css';

import LoginBtn from './component/LoginBtn';
import LiveStream from './component/LiveStream';

class App extends Component {
  render() {
    return (
      <div className="App">
        <div className="App-header">
          <img src={logo_twitch} className="App-logo" alt="logo" />
          <h2>twitch test</h2>
        </div>
        <LoginBtn />
        <LiveStream />
      </div>
    );
  }
}

export default App;
